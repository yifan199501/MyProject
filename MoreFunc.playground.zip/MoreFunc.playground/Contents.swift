func calArea(withwidth width:Float, withheight height:Float) -> Float{
    return width * height
}

calArea(withwidth: 20.5, withheight: 30.5)



func buy(thisstufff thing:String, withmoney money:Int){
    print("I want to buy \(thing) with \(money)")
}


var perfect = 100
func add(num1:Int, num2:Int) -> Int {
    let result = num1 + num2
    return result
}
